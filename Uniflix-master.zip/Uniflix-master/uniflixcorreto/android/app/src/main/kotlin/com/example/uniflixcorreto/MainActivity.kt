package com.example.uniflixcorreto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
